export const styles = {
  paddingHorizontal: "px-4 md:px-8 lg:px-24",
  bgYellow: "bg-yellow-500",
  bgGray: "bg-gray-400",
};
