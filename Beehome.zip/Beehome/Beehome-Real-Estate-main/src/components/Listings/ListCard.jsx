import React from "react";

const ListCard = () => {
  return (
    <div>
      <div></div>
    </div>
  );
};

export default ListCard;
