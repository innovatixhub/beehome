import ConsultationImg1 from "./consultation-1.png";
import ConsultationImg2 from "./consultation-2.png";

export { ConsultationImg1, ConsultationImg2 };
