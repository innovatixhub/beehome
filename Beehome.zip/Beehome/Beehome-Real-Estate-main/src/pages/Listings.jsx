import React from "react";
import List from "../components/Listings/List";

const Listings = () => {
  return (
    <div>
      <List />
    </div>
  );
};

export default Listings;
