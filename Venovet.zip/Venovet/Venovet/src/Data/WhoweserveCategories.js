import { img1 } from "../images/Bannerimages";

const Data = [
  {
    catgeory: "Fast Moving Consumer Goods (FMCG)",
    Tittle: "Fast Moving Consumer Goods (FMCG)",
    image: img1,
    Para: "Relaxes our clients to get the goods delivered at their demanded place",
  },
  {
    catgeory: "Fast Moving Consumer Durables (FMCD)",
    Tittle: "Venovet's Value Added Services (VAS)",
    image: img1,
    Para: "Relaxes our clients to get the goods delivered at their demanded place",
  },
  {
    catgeory: "Fashion & Lifestyle",
    Tittle: "Fashion & Lifestyle",
    image: img1,
    Para: "Relaxes our clients to get the goods delivered at their demanded place",
  },
  {
    catgeory: "Diary Farm",
    Tittle: "Diary Farm",
    image: img1,
    Para: "Relaxes our clients to get the goods delivered at their demanded place",
  },
  {
    catgeory: "Ecommerce Fulfillment",
    Tittle: "Ecommerce Fulfillment",
    image: img1,
    Para: "Relaxes our clients to get the goods delivered at their demanded place",
  },
  {
    catgeory: "Chemical",
    Tittle: "Chemical",
    image: img1,
    Para: "Relaxes our clients to get the goods delivered at their demanded place",
  },
  {
    catgeory: "Pharma",
    Tittle: "Pharma",
    image: img1,
    Para: "Relaxes our clients to get the goods delivered at their demanded place",
  },
  {
    catgeory: "Lens and Frames",
    Tittle: "Lens and Frames",
    image: img1,
    Para: "Relaxes our clients to get the goods delivered at their demanded place",
  },
  {
    catgeory: "Auto-Mobility",
    Tittle: "Auto-Mobility",
    image: img1,
    Para: "Relaxes our clients to get the goods delivered at their demanded place",
  },
  {
    catgeory: "Telecom",
    Tittle: "Telecom",
    image: img1,
    Para: "Relaxes our clients to get the goods delivered at their demanded place",
  },
  {
    catgeory: "Fruits & vegetables",
    Tittle: "Fruits & vegetables",
    image: img1,
    Para: "Relaxes our clients to get the goods delivered at their demanded place",
  },
  {
    catgeory: "Home & Furniture",
    Tittle: "Home & Furniture",
    image: img1,
    Para: "Relaxes our clients to get the goods delivered at their demanded place",
  },
];

export default Data;
