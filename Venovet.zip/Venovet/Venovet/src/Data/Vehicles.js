const vechilesData = [
  {
    Name: "Tata Ace",
  },
  {
    Name: "Tata Ace Closed",
  },
  {
    Name: "Tata Ace Mega",
  },
  {
    Name: "Tata Zip",
  },
  {
    Name: "Ashok Leyland Dost",
  },
  {
    Name: "Mahindra Bolero Pick Up",
  },
  {
    Name: "LCV Open Body",
  },
  {
    Name: "TATA 407 - 2.5 MT",
  },
  {
    Name: "LCV Open Body 14 Feet - 4 MT",
  },
  {
    Name: "LCV Open Body 17 Feet - 5 MT",
  },
  {
    Name: "LCV Open Body 19 Feet - 7 MT",
  },
  {
    Name: "LCV Closed Body TATA 407 - 2.5 MT",
  },
  {
    Name: "LCV Closed Body 14 Feet - 2.5 MT",
  },
  {
    Name: "LCV Closed Body 19 Feet - 7 MT",
  },
  {
    Name: " LCV Closed Body 17 Feet - 5 MT",
  },
  {
    Name: "LCV Open Body - 20 Feet -7 MT",
  },
  {
    Name: "Open Body Taurus - 6W - 9 MT",
  },
  {
    Name: "Open Body Taurus - 10W - 16 MT",
  },
  {
    Name: "Open Body Taurus - 12W - 21 MT",
  },
  {
    Name: "Open Body Taurus - 14W - 26 MT",
  },
  {
    Name: "Dala Body Taurus - 6W - 9 MT",
  },
  {
    Name: "Dala Body Taurus - 10W - 16 MT",
  },
  {
    Name: "Dala Body Taurus - 14W - 26 MT",
  },
  {
    Name: "Trailer 40 Feet - 20 MT",
  },
  {
    Name: "Trailer 40 Feet - 26 MT",
  },
  {
    Name: "ODC Trailer",
  },
  {
    Name: "Container SXL - 20 Feet - 7 MT",
  },
  {
    Name: "Container SXL - 24 Feet - 7 MT",
  },
  {
    Name: "Container SXL - 32 Feet - 7 MT",
  },
  {
    Name: "Container SXL - 40 Feet - 15 MT",
  },
  {
    Name: "Container SXL - 32 Feet High Cube - 7 MT",
  },
  {
    Name: "Container MXL - 20 Feet - 9 MT",
  },
  {
    Name: "Container MXL - 24 Feet - 14 MT",
  },
  {
    Name: "Container MXL - 32 Feet High Cube - 14 MT",
  },
  {
    Name: "Container MXL - 32 Feet - 14 MT",
  },
  {
    Name: "Trailer 20 Feet",
  },
  {
    Name: "32 Feet Open Trailor ODC -25 MT",
  },
  {
    Name: "T34 Feet Open Trailor ODC -25 MT",
  },
  {
    Name: "40 Feet Open Trailor ODC - 32 MT",
  },
];

export default vechilesData;
