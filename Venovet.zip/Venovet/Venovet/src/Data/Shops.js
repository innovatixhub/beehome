const Shop = [
  {
    Tittle: "Electronics",
    Products: [
      {
        img: "",
        name: "",
      },
    ],
  },
  {
    Tittle: "Material Handling Equipments",
    Products: [
      {
        img: "https://venovet.com/cw_admin/uploads/1648700631_hydraulic-hand-pallet-truck-500x500.jpeg",
        name: "HAND PALLET TRUCK(HPT)",
      },
    ],
  },
  {
    Tittle: "Test Category",
    Products: [
      {
        img: "",
        name: "",
      },
    ],
  },
];

export default Shop;
