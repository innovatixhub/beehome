const Data = [
  {
    q: "How commercial/business storage works?",
    a: "Our professional packers will wrap your items with utmost care. Then the movers will take your belongings to our secured storage unit which is monitored 24/7. Photographs of all your items and catalogue is prepared. When you want any of the items back, you can select a few or all of your items from the catalogue which is accessible on our app and our professionals will deliver the items at your doorstep within 72 hours.",
  },
  {
    q: " What are benefits of on-demand business storage?",
    a: "Pick up from you work place. Just pay for the space that you require. Avail great offers and get friendly professional advice from our expert team. Wide range of good quality packing materials. An option of choosing long term or short term business storage solutions. Clean and secure business storage facilities. 24 X 7 security with CCTV coverage. Integrated with Fire control systems. Regular pest control services. Insurance coverage.",
  },
  {
    q: " When do you require business/commercial storage service?",
    a: "All businesses aim to save money. With innovations in technology, many businesses are finding ways to work without a proper office. Even in such cases, they still need to find a place to store some of their equipment’s or furniture. StowNest’s storage space for rent in Hyderabad offers this space at a very reasonable rate in comparison to the rent of an office or warehouse. When you are storing everything including your valuables at your workplace or business place, there is a huge risk of losing your valuables if the security is not up to the mark which you can avoid by securing your valuable business-related possessions in a reliable storage space with 24/7 security.",
  },
  {
    q: " Will StowNest Storage help me pack?",
    a: "The movers will help you pack and move just about anything that you would like. Some bulkier or fragile items (pool tables, exercise machines) require special care and should be moved with speciality movers. Our movers do not move or store these items but are happy to provide recommendations. If you have anything that may require special arrangements, please contact the StowNest Team.",
  },
];

export default Data;
