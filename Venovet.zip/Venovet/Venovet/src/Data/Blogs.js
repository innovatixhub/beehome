const Data = [
  {
    image: "https://www.venovet.com/assets/images/resources/post-img1-2.jpg",
    Tittle: "Project ManageMent",
    Para: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Hic illum sunt",
  },
  {
    image: "https://www.venovet.com/assets/images/resources/post-img1-3.jpg",
    Tittle: "EPR soloutions",
    Para: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Hic illum sunt",
  },
  {
    image: "https://www.venovet.com/assets/images/resources/post-img1-4.jpg",
    Tittle: "Industrial Solutions",
    Para: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Hic illum sunt",
  },
  {
    image: "https://www.venovet.com/assets/images/resources/post-img1-1.jpg",
    Tittle: "Project ManageMent",
    Para: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Hic illum sunt",
  },
  {
    image: "https://www.venovet.com/assets/images/resources/post-img1-2.jpg",
    Tittle: "EPR soloutions",
    Para: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Hic illum sunt",
  },
  {
    image: "https://www.venovet.com/assets/images/resources/post-img1-3.jpg",
    Tittle: "Industrial Solutions",
    Para: "Lorem ipsum dolor sit amet consectetur adipisicing elit. Hic illum sunt",
  },
];

export default Data;
