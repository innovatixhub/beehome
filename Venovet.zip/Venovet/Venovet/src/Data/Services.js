import {
  services1,
  services2,
  services3,
  services4,
  services5,
  services6,
  services7,
  services8,
} from "../images/services/index";

const Data = [
  {
    Tittle: "WareHouse Management",
    image: services1,
  },
  {
    Tittle: "Transpotation",
    image: services2,
  },
  {
    Tittle: "Value Added Services",
    image: services3,
  },
  {
    Tittle: "SCM Automation",
    image: services4,
  },
  {
    Tittle: "Inventory Audits",
    image: services5,
  },
  {
    Tittle: "Logistics Projects Designing",
    image: services6,
  },
  {
    Tittle: "Internet Supply Chain",
    image: services7,
  },
  {
    Tittle: "ERP & Solutions",
    image: services8,
  },
];

export default Data;
