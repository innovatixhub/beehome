import { testi1, testi2, testi3 } from "../images/home/index";

const Data = [
  {
    image: testi1,
    Name: '"Jonspond Mendela"',
    p: "Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis. Vivamus ac ultrices diam, vitae accumsan tellus.",
    review: "(07 Review)",
    star: "⭐⭐⭐⭐",
  },
  {
    image: testi2,
    Name: '"Jonspond Mendela"',
    p: "Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis. Vivamus ac ultrices diam, vitae accumsan tellus.",
    review: "(07 Review)",
    star: "⭐⭐⭐⭐",
  },
  {
    image: testi3,
    Name: '"Jonspond Mendela"',
    p: "Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis. Vivamus ac ultrices diam, vitae accumsan tellus.",
    review: "(07 Review)",
    star: "⭐⭐⭐⭐",
  },
  {
    image: testi1,
    Name: '"Jonspond Mendela"',
    p: "Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis. Vivamus ac ultrices diam, vitae accumsan tellus.",
    review: "(07 Review)",
    star: "⭐⭐⭐⭐",
  },
  {
    image: testi2,
    Name: '"Jonspond Mendela"',
    p: "Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis. Vivamus ac ultrices diam, vitae accumsan tellus.",
    review: "(07 Review)",
    star: "⭐⭐⭐⭐",
  },
  {
    image: testi3,
    Name: '"Jonspond Mendela"',
    p: "Proin gravida nibh vel velit auctor aliquet. Aenean sollicitudin, lorem quis. Vivamus ac ultrices diam, vitae accumsan tellus.",
    review: "(07 Review)",
    star: "⭐⭐⭐⭐",
  },
];

export default Data;
