import { blog1, blog2, blog3 } from "../images/home";

const Blogs = [
  {
    image: blog1,
    Tittle: "Distribution Warehousing",
    SubTittle:
      "Reducing the effective logistics costs of products by 8% for an FMCG giant",
    Para: "Explore how we enabled an industry leader in the FMCG sector to boost its profits by optimising its warehousing & secondary distribution.",
  },
  {
    image: blog2,
    Tittle: "Distribution Warehousing",
    SubTittle: "Distribution Warehousing",
    Para: "Explore how we enabled an industry leader in the FMCG sector to boost its profits by optimising its warehousing & secondary distribution.",
  },
  {
    image: blog3,
    Tittle: "Distribution Warehousing",
    SubTittle:
      "Reducing the effective logistics costs of products by 8% for an FMCG giant",
    Para: "Explore how we enabled an industry leader in the FMCG sector to boost its profits by optimising its warehousing & secondary distribution.",
  },
];

export default Blogs;
