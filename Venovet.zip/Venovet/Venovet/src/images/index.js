import venovetChart from './venovetChart.jpg'



export { venovetChart }