import enquire from "./enquire.jpg";
import testi1 from "./testi1.png";
import testi2 from "./testi2.png";
import testi3 from "./testi3.png";
import faq from "./faq.png";
import blog1 from "./blogs/blog1.jpg";
import blog2 from "./blogs/blog2.jpg";
import blog3 from "./blogs/blog3.jpg";
import rocket from "./rocket_contact.jpg";
import candle from "./candle.png";

export {
  enquire,
  testi1,
  testi2,
  testi3,
  faq,
  blog1,
  blog2,
  blog3,
  rocket,
  candle,
};
