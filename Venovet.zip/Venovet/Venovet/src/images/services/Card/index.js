import icon1 from "./icon1.png";
import icon2 from "./icon2.png";
import icon3 from "./icon3.png";
import icon4 from "./icon4.png";
import s51 from "./s51.jpg";

export { icon1, icon2, icon3, icon4, s51 };
