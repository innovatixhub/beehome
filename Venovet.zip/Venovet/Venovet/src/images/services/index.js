import services1 from "./services-1.jpg";
import services2 from "./services-2.jpg";
import services3 from "./services-3.jpg";
import services4 from "./services-4.jpg";
import services5 from "./services-5.jpg";
import services6 from "./services-6.jpg";
import services7 from "./services-7.jpg";
import services8 from "./services-8.jpg";
import servicelogo from "./service-logo.png";
import image1 from "./image1.jpg";
import image2 from "./image2.jpg";

export {
  services1,
  services2,
  services3,
  services4,
  services5,
  services6,
  services7,
  services8,
  servicelogo,
  image1,
  image2,
};
