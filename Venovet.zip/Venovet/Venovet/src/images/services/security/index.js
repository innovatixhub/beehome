import sec1 from "./sec1.png";
import sec2 from "./sec2.png";
import sec3 from "./sec3.png";
import sec4 from "./sec4.png";
import sec5 from "./sec5.png";
import sec6 from "./sec6.png";
import sec7 from "./sec7.png";
import sec8 from "./sec8.png";
import sec9 from "./sec9.png";
import sec10 from "./sec10.png";

export { sec1, sec2, sec3, sec4, sec5, sec6, sec7, sec10, sec8, sec9 };
