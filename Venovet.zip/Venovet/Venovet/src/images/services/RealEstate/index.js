import re1 from "./re1.png";
import re2 from "./re2.png";
import re3 from "./re3.png";
import re4 from "./re4.png";
import re5 from "./re5.png";
import re6 from "./re6.png";
import re7 from "./re7.png";
import re8 from "./re8.png";
import re9 from "./re9.png";
import re10 from "./re10.png";
import re11 from "./re11.png";
import s32 from "./s32.jpg";
import s55 from "./s55.jpg";

export { re1, re2, re3, re4, re5, re6, re7, re8, re9, re10, re11, s32, s55 };
