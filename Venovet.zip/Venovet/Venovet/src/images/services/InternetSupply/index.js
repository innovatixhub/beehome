import sicon1 from "./sicon1.png";
import sicon2 from "./sicon2.png";
import sicon3 from "./sicon3.png";
import sicon4 from "./sicon4.png";
import sicon5 from "./sicon5.png";
import sicon6 from "./sicon6.png";
import sicon7 from "./sicon7.png";
import sicon8 from "./sicon8.png";
import sicon9 from "./sicon9.png";
import sicon11 from "./sicon11.png";
import sicon12 from "./sicon12.png";
import sicon13 from "./sicon13.png";
import sicon14 from "./sicon14.png";
import sicon15 from "./sicon15.png";
import sicon16 from "./sicon16.png";
import sicon17 from "./sicon17.png";

export {
  sicon1,
  sicon2,
  sicon3,
  sicon4,
  sicon5,
  sicon6,
  sicon7,
  sicon8,
  sicon9,
  sicon11,
  sicon12,
  sicon13,
  sicon14,
  sicon15,
  sicon16,
  sicon17,
};
