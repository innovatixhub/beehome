import s4 from "./s4.jpg";

export { s4 };
