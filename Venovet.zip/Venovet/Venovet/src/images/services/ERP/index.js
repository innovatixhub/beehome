import erp1 from "./erp-icon1.png";
import erp2 from "./erp-icon2.png";
import erp3 from "./erp-icon3.png";
import erp4 from "./erp-icon4.png";
import erp5 from "./erp-icon5.png";
import erp6 from "./erp-icon6.png";
import erp7 from "./erp-icon7.png";

export { erp1, erp2, erp3, erp4, erp5, erp6, erp7 };
