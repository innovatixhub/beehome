import why1 from "./why1.png";
import why2 from "./why2.png";
import why3 from "./why3.png";
import why4 from "./why4.png";
import why5 from "./why5.png";
import why6 from "./why6.png";

export { why1, why2, why3, why4, why5, why6 };
