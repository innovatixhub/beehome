import log1 from "./log1.png";
import log2 from "./log2.png";
import log3 from "./log3.png";
import log4 from "./log4.webp";
import log5 from "./log5.png";
import log6 from "./log6.png";
import log7 from "./log7.jpg";
import log8 from "./log8.jpg";
import log9 from "./log9.jpg";
import log10 from "./log10.jpg";
import log11 from "./log11.jpg";
import career from "./career-logo.png";

export {
  log1,
  log2,
  log3,
  log4,
  log5,
  log6,
  log7,
  log8,
  log9,
  log10,
  log11,
  career,
};
