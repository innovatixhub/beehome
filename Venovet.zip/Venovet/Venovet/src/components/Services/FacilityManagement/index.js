import FacilityServices from './FacilityServices'
import HouseKeeping from './HouseKeeping'
import StationeryPrinting from './StationeryPrinting'
import PestControl from './PestControl'
import GUESTHOUSEMANAGEMENT from './GUESTHOUSEMANAGEMENT'
import TECHNICALSERVICES from './TECHNICALSERVICES'


export { FacilityServices , HouseKeeping ,StationeryPrinting ,PestControl , GUESTHOUSEMANAGEMENT,TECHNICALSERVICES}